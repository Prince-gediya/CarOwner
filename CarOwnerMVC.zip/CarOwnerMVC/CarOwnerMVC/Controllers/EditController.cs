﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Models;
using System.Data.SqlClient;

namespace CarOwnerMVC.Controllers
{
    public class EditController : Controller
    {
        updation appobj = new updation();


        [HttpGet]
        public IActionResult edit()
        {
            return View();
        }


        [HttpPost]
        public IActionResult edit(updation update)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarO_MVC;Integrated Security=True");
            conn.Open();
            string qury = "update add_data set compname = @cname, make = @make, contect = @contect, fueltype = @fuel, price = @Price, carname = @Carname, engine = @Engine where oname = @oname";
            SqlCommand cmd = new SqlCommand(qury,conn);
            cmd.Parameters.AddWithValue("@oname", update.oname);
            cmd.Parameters.AddWithValue("@cname", update.compname);
            cmd.Parameters.AddWithValue("@make", update.make);
            cmd.Parameters.AddWithValue("@contect", update.contect);
            cmd.Parameters.AddWithValue("@fuel", update.fueltype);
            cmd.Parameters.AddWithValue("@Price", update.price);
            cmd.Parameters.AddWithValue("@Carname", update.carname);
            cmd.Parameters.AddWithValue("@Engine", update.engine);
            cmd.ExecuteNonQuery();
            TempData["msg"] = "Data Updated Successfully";
            return RedirectToAction("search","Search");
        }

    }
}
