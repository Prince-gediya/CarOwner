﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Models;
using Microsoft.Data.SqlClient;

namespace CarOwnerMVC.Controllers
{
    public class insertController : Controller
    {
        Insertdata user = new Insertdata();


        [HttpGet]
        public IActionResult insertdata()
        {
            return View();
        }

        [HttpPost]
        public IActionResult insertdata(Insertdata add)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarO_MVC;Integrated Security=True");
            String query = "insert into add_data(oname,compname,make,contect,fueltype,price,carname,engine)values(@oname,@compname,@make,@contect,@fueltype,@price,@carname,@engine)";
            SqlCommand cmd = new SqlCommand(query,con);
            cmd.Parameters.AddWithValue("@oname", add.oname);
            cmd.Parameters.AddWithValue("@compname", add.compname);
            cmd.Parameters.AddWithValue("@make", add.make);
            cmd.Parameters.AddWithValue("@contect", add.contect);
            cmd.Parameters.AddWithValue("@fueltype", add.fueltype);
            cmd.Parameters.AddWithValue("@price", add.price);
            cmd.Parameters.AddWithValue("@carname", add.carname);
            cmd.Parameters.AddWithValue("@engine", add.engine);
            con.Open();
            
            cmd.ExecuteNonQuery();
            TempData["msg"] = "Saved Successfully..";
            return RedirectToAction("edit","Edit");
        }
    }
}
