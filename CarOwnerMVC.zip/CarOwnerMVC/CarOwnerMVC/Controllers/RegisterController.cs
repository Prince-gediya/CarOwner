﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace CarOwnerMVC.Controllers
{
    public class RegisterController : Controller
    {
        register userobj = new register();

        public IActionResult Index()
        {
            return View();
        }


        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }


        //[HttpPost]
        //public IActionResult Register(register a)
        //{
        //    bool res;
        //    userobj = new register();
        //    res = userobj.Insert(a);
        //    if (res)
        //    {
        //        TempData["msg"] = "register successfully";
        //    }
        //    else
        //    {
        //        TempData["msg"] = "not register successfully";
        //    }
        //    return View();
        //}

        [HttpPost]
        public ActionResult Register(register a)    
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarO_MVC;Integrated Security=True");
            //string xyz = "";
            String query = "insert into Register(Username,Email,Password)values(@user, @email,@pass)";
            //String query = " select * from Register where Username like '%"+xyz+"%'";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", a.Username);
            cmd.Parameters.AddWithValue("@email", a.Email);
            cmd.Parameters.AddWithValue("@pass", a.Password);
            con.Open();
            cmd.ExecuteNonQuery();
            return RedirectToAction("login", "Login");

        }

    }

}
