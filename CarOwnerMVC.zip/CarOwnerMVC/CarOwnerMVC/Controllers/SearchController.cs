﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Models;

namespace CarOwnerMVC.Controllers
{
    public class SearchController : Controller
    {
        search appobj = new search();

        public IActionResult search()
        {
            appobj = new search();
            List<search> lsearch = appobj.getData();
            return View(lsearch);
        }
    }
}
