﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Models;

namespace CarOwnerMVC.Controllers
{
    public class deleteController : Controller
    {
        search empObj = new search();

        public IActionResult Index()
        {
            return View();
        }


        [HttpGet]
        public IActionResult Delete(string id)
        {
            search emp = empObj.getData(id);
            return View(emp);
        }

        [HttpPost]
        public IActionResult Delete(search emp)
        {
            bool res;
            empObj = new search();
            res = empObj.delete(emp);
            if (res)
            {
                TempData["msg"] = "Deleted Successfully..";
            }
            else
            {
                TempData["msg"] = "Not Deleted. Somthing went Wrong..!!";
            }
            return View();
        }
    }
}
