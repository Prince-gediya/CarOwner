﻿using System;
using System.Threading.Tasks;
using CarOwnerMVC.Controllers;
using ServiceStack;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using CarOwnerMVC.Models;
using CarOwnerMVC.Controllers;

namespace CarOwnerMVC.Controllers
{
    public class LoginController : Controller
    {
        Login userobj = new Login();

        public IActionResult Index()
        {
            return View();
        }

        //GET : LoginController
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Login l)
        {
            bool res;
            if (ModelState.IsValid)
            {
                userobj = new Login();
                res = userobj.check(l);
                if (res)
                {
                    string a = "Login Successfully...";
                    TempData["msg"] = a;
                    return View();
                }
                /*else
                {
                    TempData["msg"] = "Not Login, Something Went Wrong...";
                }*/
            }
            return View(l);
        }





        public IActionResult Dashboard()
        {
            return View();
        }


        public IActionResult HomePage()
        {
            return View();
        }

        public IActionResult logout()
        {
            HttpContext.Session.Remove("Username");

            return RedirectToAction("login", "Login");
        }

    }
}
