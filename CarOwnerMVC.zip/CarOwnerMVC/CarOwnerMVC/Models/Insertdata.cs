﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Models;
using CarOwnerMVC.Controllers;
using System.ComponentModel.DataAnnotations;

namespace CarOwnerMVC.Models
{
    public class Insertdata
    {
       
        public int Id { get; set; }

        public string oname { get; set; }

        public string compname { get; set; }

        public string make { get; set; }

        public string contect { get; set; }

        public string fueltype { get; set; }

        public string price { get; set; }

        public string carname { get; set; }

        public string engine { get; set; }
    }
}



/*public bool insert(Insertdata add)
        {
            string user = add.oname.Trim();
            SqlCommand cmd = new SqlCommand( "insert into add_data(oname,compname,make,contect,fueltype,price,carname,engine)values(@oname,@compname,@make,@contect,@fueltype,@price,@carname,@engine)" ,con);
            cmd.Parameters.AddWithValue("@oname", add.oname);
            cmd.Parameters.AddWithValue("@compname", add.compname);
            cmd.Parameters.AddWithValue("@make", add.make);
            cmd.Parameters.AddWithValue("@contect", add.contect);
            cmd.Parameters.AddWithValue("@fueltype", add.fueltype);
            cmd.Parameters.AddWithValue("@price", add.price);
            cmd.Parameters.AddWithValue("@carname", add.carname);
            cmd.Parameters.AddWithValue("@engine", add.engine);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                return true;
            }
            else
            {
                return false;
            }
         }*/