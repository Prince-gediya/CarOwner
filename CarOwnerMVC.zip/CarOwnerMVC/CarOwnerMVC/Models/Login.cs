﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Controllers;
using Microsoft.Data.SqlClient;

namespace CarOwnerMVC.Models
{
    public class Login
    {
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarO_MVC;Integrated Security=True");

        public int Id { get; set; }
        
        public string Username { get; set; }
        
        public string Password { get; set; }
        
        public bool check(Login l)  
        {
            string user = l.Username.Trim();
            SqlCommand com = new SqlCommand("select Username,Email,Password from Register where Username=@user and Password=@pass ",conn);
            com.Parameters.AddWithValue("@user",l.Username);
            com.Parameters.AddWithValue("@pass",l.Password);
            conn.Open();
            SqlDataReader dr = com.ExecuteReader();

            if (dr.Read())
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}



/*SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarO_MVC;Integrated Security=True");

        public bool login(Login user)
        {
            String query = "select Username,Email,Password from Register where Username=@user and Password=@pass";
            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("@user", user.Username);
            cmd.Parameters.AddWithValue("@pass", user.Password);

            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                return true;
            }
            return false;*/
            //String data = dr.GetString(2);
            //cmd.ExecuteNonQuery();
            //con.Close();
            //return data;
