﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarOwnerMVC.Controllers;
using CarOwnerMVC.Models;

namespace CarOwnerMVC.Models
{
    public class updation
    {
        public int Id { get; set; }

        public string oname { get; set; }

        public string compname { get; set; }

        public string make { get; set; }

        public string contect { get; set; }

        public string fueltype { get; set; }

        public string price { get; set; }

        public string carname { get; set; }

        public string engine { get; set; }
    }
}
