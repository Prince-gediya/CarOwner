﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using CarOwnerMVC.Models;
using System.Threading.Tasks;
using CarOwnerMVC.Controllers;

namespace CarOwnerMVC.Models
{
    public class search
    {

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Enter Ownername to fill the Details")]
        public string Ownername { get; set; }

        [Required(ErrorMessage = "Enter Company's Name")]
        public string Companyname { get; set; }

        [Required(ErrorMessage = "Enter Make/Model Name")]
        public string Make { get; set; }

        [Required(ErrorMessage = "Enter Contect No.")]
        public string Contect { get; set; }

        [Required(ErrorMessage = "Enter Fuel Type")]
        public string Fueltype { get; set; }

        [Required(ErrorMessage = "Enter Price")]
        public string Price { get; set; }

        [Required(ErrorMessage = "Enter Carname")]
        public string Carname { get; set; }

        [Required(ErrorMessage = "Enter Engine No.")]
        public string Engine { get; set; }

        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CarO_MVC;Integrated Security=True");

        public List<search>getData()
        {
            List<search> lsearch = new List<search>();
            SqlDataAdapter apt = new SqlDataAdapter("select * from add_data",con);
            DataSet ds = new DataSet();
            apt.Fill(ds);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lsearch.Add(new search
                {
                    Id=Convert.ToInt32(dr["Id"].ToString()),
                    Ownername=dr["oname"].ToString(),
                    Companyname=dr["compname"].ToString(),
                    Make=dr["make"].ToString(),
                    Fueltype=dr["contect"].ToString(),
                    Price=dr["price"].ToString(),
                    Carname=dr["carname"].ToString(),
                    Engine=dr["engine"].ToString()
                });
            }
            return lsearch;
        }

        //SEARCH

        public search getData(string Id)
        {
            search emp = new search();
            SqlCommand cmd = new SqlCommand("select * from add_data where id='" + Id +
           "'", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    emp.Id = Convert.ToInt32(dr["Id"].ToString());
                    emp.Ownername = dr["oname"].ToString();
                    emp.Companyname = dr["compname"].ToString();
                    emp.Make = dr["make"].ToString();
                    emp.Contect = dr["contect"].ToString();
                    emp.Fueltype = dr["fueltype"].ToString();
                    emp.Price = dr["price"].ToString();
                    emp.Carname = dr["carname"].ToString();
                    emp.Engine = dr["engine"].ToString();
                }
            }
            con.Close();
            return emp;
        }

        //DELETE RECORD

        public bool delete(search Emp)
        {
            SqlCommand cmd = new SqlCommand("delete add_data where Id = @id", con);
            cmd.Parameters.AddWithValue("@id", Emp.Id);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            if (i >= 1)
            {
                return true;
            }
            return false;
        }

    }
}
